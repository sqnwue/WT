tesla webpage using props,usestate,routing,components,es6
