Website link will be given
implement till one level of depth
COmponents
heirarchy
esx,jsx,functional component
USe state
Prop
React routing
CSS/bootstrap
coding process
totol 80
2nd question 
lab exercise and code from ppts
20marks

npm create vite@latest

npx create-react-app myapp

npm install react-router-dom

npm install styled-components

npm install bootstrap
