import React from 'react';
import './Careers.css';

function Careers() {
  return (
    <div className="careers">
      <h1>Careers</h1>
      <p>Join our team and help drive digital transformation worldwide.</p>
    </div>
  );
}

export default Careers;
