import React from 'react';
import './ECommerce.css';

function ECommerce() {
  return (
    <div className="ecommerce">
      <h1>E-commerce</h1>
      <p>Explore our E-commerce solutions...</p>
    </div>
  );
}

export default ECommerce;
