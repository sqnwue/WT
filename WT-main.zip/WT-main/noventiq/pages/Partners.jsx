import React from 'react';
import './Partners.css';

function Partners() {
  return (
    <div className="partners">
      <h1>Partners</h1>
      <p>We collaborate with industry leaders to provide exceptional solutions for our clients.</p>
    </div>
  );
}

export default Partners;
